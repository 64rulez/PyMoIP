# arbo_demo-jet7.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-Minitel-Mushussu/1/"
FirstFile=11
LastFile=13
PrefixFile="J"
GuideLink="arbo_inter"

