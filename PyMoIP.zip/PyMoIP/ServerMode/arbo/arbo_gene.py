# arbo_gene.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-Minitel-Mushussu/1/"
FirstFile=1
LastFile=1
PrefixFile="GENE5"
PostfixFile=""
