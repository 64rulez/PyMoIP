# arbo_inter.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-Minitel-Mushussu/1/"
FirstFile=1
LastFile=1
PrefixFile="INTER"
PostfixFile=".vdt"
GuideLink="arbo_interbis"
VarList=[]
