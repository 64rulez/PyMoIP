# %arbo%/EdtaTestMenu/DoodleHaMinitel.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-PyMoIP/Doodle/HaMinitel/"
FirstFile=1
LastFile=3
PrefixFile="1_Photo_"
PostfixFile=".vdt"
VarList=[[1,5,[],"%NumPageVdt",1,"/"],[1,7,[],"%NumPagesVdt",1," "]]
