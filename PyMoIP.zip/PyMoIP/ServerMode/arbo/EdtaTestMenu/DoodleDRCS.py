# %arbo%/EdtaTestMenu/DoodleDRCS.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-PyMoIP/Doodle/DRCS/"
FirstFile=1
LastFile=158
PrefixFile="2_DRCS_"
PostfixFile=".vdt"
VarList=[[0,30,[],"%NumPageVdt",3,"/"],[0,34,[],"%NumPagesVdt",3," "]]
