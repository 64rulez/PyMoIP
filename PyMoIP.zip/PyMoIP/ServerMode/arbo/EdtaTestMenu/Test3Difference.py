# %arbo%/EdtaTestMenu/Test3Difference.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-PyMoIP/TestEdta/"
FirstFile=1
LastFile=8
PrefixFile="EDTA_MenuMT3"
VarList=[[1,35,[],"%NumPageVdt",2,"/"],[1,37,[],"%NumPagesVdt",2," "]]
