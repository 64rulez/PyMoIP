# %arbo%/EdtaTestMenu/TesBugt1Simple.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-PyMoIP/TestEdta/"
FirstFile=1
LastFile=2
PrefixFile="EDTA_MenuMT4"
VarList=[[1,35,[],"%NumPageVdt",2,"/"],[1,37,[],"%NumPagesVdt",2," "]]
