# %arbo%/EdtaTestMenu/DoodlePaves.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-PyMoIP/Doodle/Paves/"
FirstFile=1
LastFile=158
PrefixFile="3_Pave_"
PostfixFile=".vdt"
VarList=[[0,30,[],"%NumPageVdt",3,"/"],[0,34,[],"%NumPagesVdt",3," "]]
