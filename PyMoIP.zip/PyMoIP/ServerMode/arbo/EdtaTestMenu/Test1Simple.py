# %arbo%/EdtaTestMenu/Test1Simple.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-PyMoIP/TestEdta/"
FirstFile=1
LastFile=4
PrefixFile="EDTA_MenuMT1"
VarList=[[1,32,[],"%NumPageVdt",2,"/"],[1,34,[],"%NumPagesVdt",2," "]]
