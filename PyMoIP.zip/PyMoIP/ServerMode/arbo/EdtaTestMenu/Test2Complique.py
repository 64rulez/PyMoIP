# %arbo%/EdtaTestMenu/Test2Complique.py

PageDir="/home/pi/python/PyMoIP/TestPages/Serveur-PyMoIP/TestEdta/"
FirstFile=1
LastFile=7
PrefixFile="EDTA_MenuMT2"
VarList=[[1,35,[],"%NumPageVdt",2,"/"],[1,37,[],"%NumPagesVdt",2," "]]
