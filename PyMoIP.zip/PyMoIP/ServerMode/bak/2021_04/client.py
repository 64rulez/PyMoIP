#!/usr/bin/env python

# WS client example

import asyncio
import websockets

async def hello():
    uri = "ws://localhost:8765"
    async with websockets.connect(uri) as websocket:
        print ("CLIENT SAYS Connected to {}".format(uri))
        Continue=True
        while Continue == True:
                name = input("Continue [y/N]? ")
                if name == "N":
                        Continue=False
                else:
                        await websocket.send(name)
                        print(f"CLIENT SENT> '{name}'")

                        greeting = await websocket.recv()
                        print(f"CLIENT GOT< '{len(greeting)}' bytes")

asyncio.get_event_loop().run_until_complete(hello())
