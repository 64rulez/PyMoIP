zozo = "zaza"
refs    = locals()
def set_pets():
    global refs
    animals = ('dog', 'cat', 'fish', 'fox', 'monkey', 'truc')
    for i in range(len(animals)):
        refs['pet_0%s' % i] = animals[i]   
        
def print_something():
  print("Something")
  
set_pets()
print(pet_00, pet_02, pet_04, pet_01, pet_03, pet_04, pet_05 )
refs['pet_05']='Variable globale'
print(pet_00, pet_02, pet_04, pet_01, pet_03, pet_04, pet_05 )

def hello():
  class Arbo:
    def __init__(self,ArboRoot):
        self.ArboCur    = ArboRoot + "."
        self.module=None
        self.func=None
  
    def SetArbo (self,ModuleToLoad):
        print("Chargement du module " + ModuleToLoad + " dans SetArbo()")
        self.module = __import__(ModuleToLoad)
        self.func = getattr(self.module, 'bar')
  
  Blabla = "Blabla défini dans hello()"      
  MyArbo = Arbo("Item arbo de l'objet MyArbo défini dans hello()") # Init l'objet
  MyArbo.SetArbo("foo_module")                                     # Importe le module
  MyArbo.func(refs,locals(),"Appel du module par MyArbo.func()")   # Appelle la fonction
  print("Blabla après bar() : " + Blabla)
  print("MyArbo.ArboCur après bar()" + MyArbo.ArboCur)

  Blabla = "Blabla défini dans hello()"      
  (getattr(MyArbo.module, 'bar'))(refs,locals(),"Appel direct du module de la fonction bar()")
  print("Blabla après bar() : " + Blabla)
  print("MyArbo.ArboCur après bar()" + MyArbo.ArboCur)

hello()
        
print(pet_00, pet_02, pet_04, pet_01, pet_03, pet_04, pet_05, pet_06 )
