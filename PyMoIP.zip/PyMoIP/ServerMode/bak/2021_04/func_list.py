# Une liste est d�finie dans un fichier "Arbo" par DisplayList=[], cette d�finition est m�moris�e dans MyArbo.DisplayList
#
# Une liste est une suite d'objets python comportant un certain nombre d'�l�ments destin�e � �tre affich�e.
# - Les caract�ristiques de l'affichage sont pr�cis�s dans le fichier d'arborescence
# - Un sous-ensemble d'�l�ments peut �tre affich�.
#
# Cette liste peut �tre :
# - Globale : Son nom est pr�fix� par '*' et c'est toujours la m�me qui sera r�f�r�nc�e, quelle que soit la session
# - Locale  : Son nom est pr�fix� par '%' - elle est locale � hello(), en cons�quence, chaque session � sa propre liste et aucune autre session ne peut y acc�der 
# - Globalle et postfix�e de l'identifiant de session : Sans pr�fixe, elle est globale et peut donc �tre acc�d�e par n'importe quelle session mais chaque session dispose de la sienne propre 
#
# MyArbo.DisplayList[] :
# <LIST_NAME> .... Nom de la liste (incluant l'�ventuel pr�fixe)
# <LIST_NB_LIN> .. Nombre de lignes d'affichage de la liste [Mini 1 ....]
# <LIST_NB_COL> .. Nombre de colones d'affichage de la liste [Mini 1 ....]
# <LIST_FIRST_LIN> Position du premier �l�ment de la liste
# <LIST_FIRST_COL> Position du premier �l�ment de la liste
# <LIST_SIZE_COL>  Nombre de colones (caract�res) d'une colonne de la liste 
# <LIST_DEFS>[] .. D�finition des �l�ments � afficher dans la liste (voir plus bas)
# <LIST_FILL_1> .. Caract�re de remplissage/effacement avant affichage de la liste. Si vide, pas d'effacement avant l'affichage.
# <LIST_ATTR_1>[]. Attributs de remplissage/effacement avant affichage de la liste
# <LIST_FILL_2> .. Caract�re de remplissage apr�s les �l�ments affich�s de la liste
# <LIST_ATTR_2>[]. Attributs de remplissage apr�s les �l�ments affich�s de la list
#
# LIST_DEFS[] 
# <LIST_DEF_ITEM>   Num�ro de l'�l�ment de la liste � afficher (0 = index) 
# <LIST_DEF_COLS>   Nombre de colonnes (caract�res) de l'�l�ment � afficher
# <LIST_DEF_SKIP>   Nombre de colonnes (caract�res) � sauter avant d'afficher l'�l�ment
# <LIST_DEF_ATTR>[] Attributs pour l'affichage de l'�l�ment
#
# MyArbo.PageDisplayList : Num�ro de page de la liste demand� pour l'affichage
# MyArbo.NumPageDisplayList  : Num�ro de page de la liste en cours d'affichage
# MyArbo.NumPagesDisplayList : Nombre total de pages de la liste en cours d'affichage
# MyArbo.CurrentListDefs=MyDefs 
# MyArbo.CurrentList[] : 
#
# GetList(MyList)   - Retourne le contenu de la liste (tous les objets/�l�ments). Appel� par CalcDisplayList()
# CalcDisplayList() - Pr�pare l'ensemble des caract�res � envoyer pour afficher la liste
#
LIST_NAME     = 0
LIST_NB_LIN   = 1
LIST_NB_COL   = 2
LIST_FIRST_LIN= 3
LIST_FIRST_COL= 4
LIST_SIZE_COL = 5
LIST_DEFS     = 6
LIST_FILL_1   = 7
LIST_ATTR_1   = 8
LIST_FILL_2   = 9
LIST_ATTR_2   = 10
#
LIST_DEF_ITEM = 0
LIST_DEF_COLS = 1
LIST_DEF_SKIP = 2
LIST_DEF_ATTR = 3

    def GetList(MyVar):
      nonlocal MySession
      nonlocal MyArbo
      
      try:   
        if (MyVar[:1]=="*") :                                # Valeur globale
          MyTempVal = refs[MyVar[1:]]
        elif (MyVar[:1]=="%") :
          MyTempVal=vars(vars().get("MyArbo")).get(MyVar[1:])
        else:                                                # Valeur globale index�e sur session => 'Locale'
          MyTempVal = refs[refs_prefix + MyVar + "_" + str(MySession)]
      except KeyError:
        print ("KeyError-> '"+ MyVar + "[]' not found")
        #print(refs["MyArbo."+MyVar])
        #print(refs)
        MyTempVal = ""
        pass
      if type (MyTempVal) is int:
        MyTempVal = str(MyTempVal)
      #if type (MyTempVal) is str:
        #MyTempVal = MyTempVal.encode('utf-8')
      #print ("GetList(" + MyVar + "[])=" + (MyTempVal.decode('utf8', 'strict')))
      print ("GetList(" + MyVar + "[])=")
      print (MyTempVal)
      return MyTempVal

    def CalcDisplayList():
      nonlocal MyArbo
      
      #MyArbo.InsertPostBytes=bytearray()
      if len(MyArbo.DisplayList) :
        MyList=GetList(MyArbo.DisplayList[LIST_NAME])
        MyNbLin=MyArbo.DisplayList[LIST_NB_LIN]          # D�finition des champs de la liste
        MyNbCol=MyArbo.DisplayList[LIST_NB_COL]          # D�finition des champs de la liste
        MyFirstLin=MyArbo.DisplayList[LIST_FIRST_LIN]    # D�finition des champs de la liste
        MyFirstCol=MyArbo.DisplayList[LIST_FIRST_COL]    # D�finition des champs de la liste
        MySizeCol=MyArbo.DisplayList[LIST_SIZE_COL]      # D�finition des champs de la liste
        MyDefs=MyArbo.DisplayList[LIST_DEFS]             # D�finition des champs de la liste
        MyFill1=MyArbo.DisplayList[LIST_FILL_1]          # D�finition des champs de la liste
        MyAttr1=MyArbo.DisplayList[LIST_ATTR_1]          # D�finition des champs de la liste
        MyFill2=MyArbo.DisplayList[LIST_FILL_2]          # D�finition des champs de la liste
        MyAttr2=MyArbo.DisplayList[LIST_ATTR_2]          # D�finition des champs de la liste
        
        MyItemsPerPage=MyNbLin*MyNbCol
        MyNbPage=len(MyList)//MyItemsPerPage
        if MyArbo.PageDisplayList < 0:
          MyArbo.PageDisplayList=0
        if MyArbo.PageDisplayList > MyNbPage:
          MyArbo.PageDisplayList=MyNbPage
        MyArbo.NumPageDisplayList = (str(MyArbo.PageDisplayList+1)).encode('utf-8')
        MyArbo.NumPagesDisplayList= (str(MyNbPage+1)).encode('utf-8')
        print("Values in '" + MyArbo.DisplayList[LIST_NAME] + "'=")
        print(MyList)
        print("NbLin:" + str(MyNbLin) + " NbCol:" + str(MyNbCol) + " FirstLin:" + str(MyFirstLin) + " FirtstCol:" + str(MyFirstCol) + " SizeCol:" + str(MySizeCol))
        print("NbPage:" + str(MyNbPage) + " CurPage:" + str(MyArbo.PageDisplayList) + " ItemPerPage:" + str(MyItemsPerPage))
        if len(MyFill1) >0 :
          for ItemLin in range (0,MyNbLin):
            MyArbo.InsertPostBytes.extend ((CHAR_US + chr(64+MyFirstLin+ItemLin)+chr(64+MyFirstCol)).encode('utf-8'))
            for Attrib in MyAttr1:                                # Ajout de chaque attribut d�fini
              MyArbo.InsertPostBytes.extend ((CHAR_ESC + Attrib).encode('utf-8'))
            if ItemLin == 0:
              MyArbo.InsertPostBytes.extend (MyFill1.encode('utf-8'))
            MyArbo.InsertPostBytes.extend (CHAR_REP.encode('utf-8'))
            if ItemLin == 0:
              MyArbo.InsertPostBytes.extend (chr(64+MySizeCol*MyNbCol-1).encode('utf-8'))
            else:
              MyArbo.InsertPostBytes.extend (chr(64+MySizeCol*MyNbCol).encode('utf-8'))
        MyCountItem = 0
        MyArbo.CurrentListDefs=MyDefs
        MyArbo.CurrentList=[]
        SizeItem=0
        for MyDef in MyDefs :
          print(MyDef)
          SizeItem += MyDef[LIST_DEF_COLS]
        for ItemCol in range(0,MyNbCol):
          for ItemLin in range (0,MyNbLin):
            CurItem=((MyArbo.PageDisplayList*MyItemsPerPage)+(ItemCol*MyNbLin)+ItemLin)
            if len (MyList)>CurItem and len(MyDefs)>0 :
              MyArbo.CurrentList.append (MyList[CurItem])
              if SizeItem ==0 :
                print("NoItemToDisplay")
                # Aucun champ n'est � afficher
                #pass
              else:
                MyArbo.InsertPostBytes.extend ((CHAR_US + chr(64+MyFirstLin+ItemLin) + chr(64+MyFirstCol+MySizeCol*ItemCol)).encode('utf-8'))
                for Attrib in MyAttr2:                                # Ajout de chaque attribut d�fini
                  MyArbo.InsertPostBytes.extend ((CHAR_ESC + Attrib).encode('utf-8'))
                print("MyCountItem (index in the display):" + str(MyCountItem))
                print("ItemInTheList:"+str(CurItem) + " ItemLin:" + str(ItemLin) + " ItemCol:" + str(ItemCol) + " CurItem():" + str((ItemCol*MyNbLin)+ItemLin))
                print(MyList[CurItem])
                for MyDef in MyDefs:
                  if MyDef[LIST_DEF_ITEM] == 0:
                    MyValue=MyCountItem+1
                  else:
                    MyValue=(MyList[CurItem][MyDef[ITEM]-1])
                  if (type (MyValue) is int) :
                    MyValue = str(MyValue)
                  print("Value:" + MyValue)
                  if len(MyValue) > MyDef[LIST_DEF_COLS]:
                    MyValue = MyValue[:MyDef[LIST_DEF_COLS]]
                  MyInsert=MyDef[LIST_DEF_SKIP]
                  while MyInsert>0:
                    MyArbo.InsertPostBytes.extend (chr(9).encode('utf-8'))
                    MyInsert -= 1
                  for Attrib in MyDef[LIST_DEF_ATTR]:                                # Ajout de chaque attribut d�fini
                    MyArbo.InsertPostBytes.extend ((CHAR_ESC + Attrib).encode('utf-8'))
                  MyArbo.InsertPostBytes.extend (MyValue.encode('utf-8'))
                  if MyDef[LIST_DEF_COLS]>len(MyValue):
                    MyArbo.InsertPostBytes.extend (MyFill2.encode('utf-8'))
                    if (MyDef[LIST_DEF_COLS]-len(MyValue)) > 2:
                      MyArbo.InsertPostBytes.extend ((CHAR_REP+chr(64+MyDef[1]-len(MyValue)-1)).encode('utf-8'))
                    elif (MyDef[LIST_DEF_COLS]-len(MyValue)) == 2:
                      MyArbo.InsertPostBytes.extend (MyFill2.encode('utf-8'))
            MyCountItem += 1                    
        print(MyDefs)
        print(MyArbo.CurrentList)
        print(MyArbo.CurrentListDefs)
      #pass

