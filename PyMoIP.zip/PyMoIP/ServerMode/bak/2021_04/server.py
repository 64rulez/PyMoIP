#!/usr/bin/envh python

# WS server example
import sys
import asyncio
import websockets
import threading

TestList=[["Toto1",123,"AAA1"],["Tata1",456,"AAA2"],["Titi1",7890,"AAA3"],["Toto2",1230,"AAA4"],["Tata2",4560,"AAA5"],["Titi2",7890,"AAA6"],["Toto2",1232,"AAA7"],["Tata2",4562,"AAA8"],["Titi2",7891,"AAA9"],["Toto3",1233,"AAA10"],["Tata3",4563,"AAA11"],["Titi3",7893,"AAA12"]]

#
# Variables globales
#
DoEchoBufferInput  = True  # Effectue l'écho des caractères bufferisés
DoRefreshPrevField = False # Lors d'un changement de champ, réaffiche le champ qui vient d'être quitté avant d'afficher le nouveau champ en cours de saisie  
 
NumSession=0    # Nombre de sessions actuellement ouvertes
TotalSession=0  # Nombre de sessions ouvertes depuis le début de l'exécution du serveur - Devriendra l'identifiant unique de session
ListSession=[]  # Liste de toutes les sessions ouvertes - Contient [<MySession>,<Remote_IP>]
refs = locals()             # Accès indirect aux variables partagées (Field)
refs_prefix = "_PyMoIp_"    # Toutes les variables partagées sont préfixées par cette constante et postfixées par '_<MySession>'
lock = threading.Lock()

def handle_exception(loop, context):
    # https://github.com/aaugustin/websockets/issues/338
    # context["message"] will always be there; but context["exception"] may not
    msg = context.get("exception", context["message"])
    print(f"Caught exception: {msg}")
    #asyncio.create_task(shutdown(loop))
    #logging.error(f"Caught exception: {msg}")
    #logging.info("Shutting down...")
    #asyncio.create_task(shutdown(loop))

def GetPage(fichier):
    # "Envoi du contenu d'un fichier"
    f = open(fichier, 'rb')
    contents=f.read()
    f.close()
    return (contents)

async def hello(websocket, path):
  try:
    Remote_IP = websocket.remote_address[0]
    global NumSession
    global TotalSession
    global ListSession
    global refs
    global lock
    
    NumSession = NumSession + 1
    try:
      lock.acquire()
      # --- Code should be atomic
      TotalSession = TotalSession + 1
      MySession = TotalSession
      ListSession.append([MySession,Remote_IP])
      # -----
    finally :
        lock.release()
        
    print(f"STARTED hello() FROM  '{Remote_IP}' NumUsers={NumSession} MySession={MySession}.")
    
    class Arbo:
        import func_list
    
        def __init__(self,ArboRoot):
            self.ArboRoot    = ArboRoot + "."
            self.ArboCur     = "<None>"         # Position actuelle dans l'arborescence - "<None>" avant d'entrer 
            self.FirstFile   = 0                # Numéro de la première page (utile lorsqu'une séquence de plusieurs pages existe à cet emplacement de l'arbo) [accessibles par SUITE/RETOUR]  
            self.LastFile    = 0                # Numéro de la dernière page (utile lorsqu'une séquence de plusieurs pages existe à cet emplacement de l'arbo) [accessibles par SUITE/RETOUR]
            self.CurFile     = ""               # Numéro de la page actuelle - commence par la première (utile lorsqu'une séquence de plusieurs pages existe à cet emplacement de l'arbo) [modifié par SUITE/RETOUR]
            self.PrefixFile  = ""               # Préfixe du nom des pages de la séquence (ex : MENU_ pour une page qui serait nommée MENU_1_TEST.VDT)
            self.PostfixFile = ""               # Postfixe du nom des pages de la séquence (ex : _TEST.vdt pour une page qui serait nommée MENU_1_TEST.VDT)
            self.PageDir     = ""               # Répertoire où se trouve la séquence de pages pour cet emplacement de l'arborescence
            self.GuideLink   = ""
            self.VarList     = list()           # Ceci contient la liste des variables à évaluer dynamiquement dans self.InsertPostBytes
            self.FieldList   = list()           # Ceci contient la liste des champs à évaluer dynamiquement dans self.InsertPostFields XXXXXXXXXXXXXXXXXXXXXXXXXXXXX
            self.DisplayList = list()           # Définition de la liste en cours d'affichage
            self.MenuList    = list()
            #
            self.CurrentList = list()           # Contenu des champs de la liste en cours d'affichage
            self.CurrentListDefs = list()       # Définition des champs de la liste en cours d'affichage
            self.CurField    = 0                # Numéro de champ en cours de saisie
            self.PageDisplayList = 0            # Numéro de page actuel dans la liste
            self.InsertBytes = bytearray()      # Ceci est arbitrairement envoyé avant la page, et effacé une fois la page envoyée
            self.InsertPostBytes = bytearray()  # Ceci correspond aux variables à inclure à la page, évalué et mis en forme au moment du chargement de la page. Est envoyé après la page.
            self.InsertPostField = bytearray()  # Ceci correspond aux champs à inclure à la page, évalué et mis en forme au moment du chargement de la page. Est envoyé après la page et InsertPostBytes.XXXXXXXXXXXXXX
            self.StackList   = list()           # Liste des points de l'arborescence empilés (lors de 'guide' par ex) pour retour avec sommaire
            
        def SetArbo (self,ArboCur):
            nonlocal NumPage,NumPages
            
            #from arbo.arbo_start import FirstFile, LastFile, PrefixFile, PostfixFile, PageDir, GuideLink
            print(f"SERVER ARBO MOVE from '{self.ArboCur}' to '{ArboCur}'")
            if self.ArboCur == "<None>":
              self.InsertBytes= (chr(31)+"00"+chr(24)+chr(27)+"T Arriving"+chr(10)).encode('utf-8') # Hello
              print(f"ARRIVING")
              
            self.ArboCur=ArboCur
            # Chargement des valeurs d'arbo par défaut (pour ne pas devoir définir chaque variable dans chaque fichier <arbo>.py) 
            _tempDef = __import__(self.ArboRoot+"arbo_defaultvar", globals(), locals(), ['FirstFile', 'LastFile', 'PrefixFile', 'PostfiFile', 'PageDir', 'GuideLink', 'VarList', 'FieldList', 'DisplayList', 'MenuList'], 0)
            self.FirstFile   = _tempDef.FirstFile
            self.LastFile    = _tempDef.LastFile
            self.PrefixFile  = _tempDef.PrefixFile
            self.PostfixFile = _tempDef.PostfixFile
            self.PageDir     = _tempDef.PageDir
            self.GuideLink   = _tempDef.GuideLink
            self.VarList     = _tempDef.VarList
            self.FieldList   = _tempDef.FieldList
            self.DisplayList = _tempDef.DisplayList
            self.MenuList    = _tempDef.MenuList
            # Chargement des valeurs d'arbo spécifiques à l'emplacement actuel dans l'arborescence (ArboCur)
            _temp    = __import__(self.ArboRoot+self.ArboCur, globals(), locals(), ['FirstFile', 'LastFile', 'PrefixFile', 'PostfiFile', 'PageDir', 'GuideLink', 'VarList', 'FieldList', 'DisplayList', 'MenuList'], 0)
            try:
              self.FirstFile   = _temp.FirstFile
            except:
              pass
            try:
              self.LastFile    = _temp.LastFile
            except:
              pass
            try:
              self.PrefixFile  = _temp.PrefixFile
            except:
              pass
            try:
              self.PostfixFile = _temp.PostfixFile
            except:
              pass
            try:
              self.PageDir     = _temp.PageDir
            except:
              pass
            try:
              self.GuideLink   = _temp.GuideLink
            except:
              pass
            try:
              self.VarList     = _temp.VarList
            except:
              pass
            try:
              self.FieldList   = _temp.FieldList
            except:
              pass
            try:
              self.DisplayList = _temp.DisplayList
            except:
              pass
            try:
              self.MenuList    = _temp.MenuList
            except:
              pass

            self.CurFile  = self.FirstFile    # Première page (dans une séquence de pages) 
            self.CurField = 0                 # Premier champ de saisie
            self.PageDisplayList = 0          # Première page sur la liste affichée
            self.CurrentList = list()         # La liste actuellement affichée ne contient aucun item
            self.CurrentListDefs = list()       # Définition des champs de la liste en cours d'affichage
            NumPage    = bytearray()
            NumPages   = bytearray()
            
#            except:
#              self.InsertBytes = (chr(12)+str(sys.exc_info()[0])+chr(10)+chr(13)+str(sys.exc_info()[1])).encode('utf-8')  #+chr(10)+chr(13)+str(sys.exc_info()[2])
#              print ("ERR:SetArbo "+str(sys.exc_info()[0])+" "+str(sys.exc_info()[1])+" "+str(sys.exc_info()[2]))
#              pass

    def GetField(MyVar,MySession):
      try:                                                   # Valeur globale
        MyTempVal = refs[refs_prefix + MyVar + "_" + str(MySession)]
      except KeyError:
        print ("KeyError-> '"+ MyVar + "_" + str(MySession) + "' not found")
        MyTempVal = ""
        pass
      if type (MyTempVal) is int:
        MyTempVal = str(MyTempVal)
      if type (MyTempVal) is str:
        MyTempVal = MyTempVal.encode('utf-8')
      print ("GetField(" + MyVar + ")=" + (MyTempVal.decode('utf8', 'strict')))
      return MyTempVal
    
    def DeclareField(MyField):
        print("DeclareField(" + MyField + ")")
        refs[refs_prefix + MyField + "_" + str(MySession)] = ""

    def FreeAllFields():
        print("FreeAllFields()")
        for key in [*refs]:
          if key[:len(refs_prefix)] == refs_prefix: 
              if key[len(key)-(len(str(MySession))+1):] == "_" + str(MySession) :
                print(key + " deleted")
                refs.pop(key)
              else :
                print(key + " kept")

    def LoadBufferInputWithCurField():
      nonlocal BufferInput
      BufferInput=GetField(MyArbo.FieldList[MyArbo.CurField][FIELD_NAME],MySession).decode('utf-8','strict')
      print("LoadBufferInputWithCurField(" + MyArbo.FieldList[MyArbo.CurField][FIELD_NAME]+ ")")
      
    def UpdateField(MyVar,MySession,MyBuffer):
      nonlocal BufferInput
      
      print("UpdateField("  + MyVar + "," + str(MySession) + ",'" + MyBuffer + "')")
      refs[refs_prefix + MyVar + "_" + str(MySession)] = MyBuffer.encode('utf-8')
      #print(refs[refs_prefix + MyVar + "_" + str(MySession)])
    
    def UpdateCurField():
      nonlocal MySession
      nonlocal BufferInput
      
      print("UpdateCurField("  + str(MySession) + ",'" + BufferInput + "')")
      if len(MyArbo.FieldList) :
        UpdateField(MyArbo.FieldList[MyArbo.CurField][FIELD_NAME],MySession,BufferInput)
        ClearBufferInput()

    def PresentFieldValue (MyVar):
      InsertPostField = bytearray()
      
      MyTempStr=CHAR_US + chr(64+MyVar[FIELD_POSV])+chr(64+MyVar[FIELD_POSH])    # Positionnement au début
      for Attrib in MyVar[FIELD_ATTRIBS]:                                        # Ajout de chaque attribut défini
        MyTempStr += CHAR_ESC
        MyTempStr += Attrib
      MyTempVal=GetField(MyVar[FIELD_NAME],MySession)                   # Valeur globale
      # Optimisations possibles si len(MyTempVal = 0)
      InsertPostField.extend (MyTempStr.encode('utf-8'))
      if MyVar[FIELD_SIZE]>0:
        InsertPostField.extend (MyVar[FIELD_FILL].encode('utf-8'))
        if MyVar[FIELD_SIZE]>3:
          Repet=MyVar[FIELD_SIZE]-1
          while Repet > 0:
            InsertPostField.extend (CHAR_REP.encode('utf-8'))
            if Repet < 64 :
              InsertPostField.extend (chr(64+Repet).encode('utf-8'))
              Repet = 0
            else :
              InsertPostField.extend (chr(64+63).encode('utf-8'))
              Repet -= 63
        else:
          if MyVar[FIELD_SIZE]==3:
            InsertPostField.extend (MyVar[FIELD_FILL].encode('utf-8'))
          InsertPostField.extend (MyVar[FIELD_FILL].encode('utf-8'))
        InsertPostField.extend (MyTempStr.encode('utf-8'))                
      InsertPostField.extend (MyTempVal)
      return InsertPostField

    def ClearBufferInput():
      nonlocal BufferInput

      print("ClearBufferInput()")
      BufferInput = ""
      
    
    def AddItemToBufferNoRomRamNoLog(item):
        nonlocal BufferInput
        nonlocal BufferEcho

        if len(BufferInput)>2:
          if (ord(BufferInput[-1:])==ord(CHAR_SS2.encode('utf-8'))) and (chr(ord(item)) in CHAR_ACCENT_LIST) :
            if (ord(BufferInput[-3:-2])==ord(CHAR_SS2.encode('utf-8'))) and (chr(ord(BufferInput[-2:-1])) in CHAR_ACCENT_LIST) :
              BufferInput=BufferInput[:-2]
        BufferInput+=item
        if DoEchoBufferInput == True:
          BufferEcho += item
    
    def AddItemToBufferNoRomRam(item):
        #
        # Ici, le traitement ROM/RAM a déjà été effectué - Ne bufferise pas [RC] ni [ESC] (mais accepte les autres codes de contrôle)
        #
        nonlocal DebugInput

        if item >= ' ':
            DebugInput += item
            AddItemToBufferNoRomRamNoLog(item)
        else:
            if item == CHAR_RC:
                DebugInput += "[RC]"
                # Prevoir traitement de [RC] comme [ENVOI]
            elif item == CHAR_ESC:
              DebugInput += "[ESC]"
            else:
                AddItemToBufferNoRomRamNoLog(item)
                DebugInput += "<0x{:02x}> ".format(ord(item))


    def AddItemToBuffer(item):
        #nonlocal BufferInput
        nonlocal DebugInput
        #nonlocal MyArbo
        nonlocal ReplyRomRamExpect,ReplyRomRamIndex,ReplyRomRam,ReplyRomRamPending
        nonlocal GotRom,GotRam1,GotRam2
        
        if ReplyRomRamExpect > 0 :      # Si on prévoit de recevoir ROM/RAM
           if item == CHAR_SOH :                            # On se prépare à recevoir des éléments de ROM/RAM
             DebugInput += "[SOH]"
             ReplyRomRamPending = True                      # Les prochains caractères reçus seront des éléments de ROM/RAM
             ReplyRomRamIndex = 0                           # On n'en a encore reçus aucun
             if ReplyRomRam == 0 :                          # On attends ROM
               GotRom = bytearray()
             elif ReplyRomRam == 1 :                        # On attends RAM1
               GotRam1 = bytearray()
             elif ReplyRomRam == 2 :                        # On attends RAM2
               GotRam2 = bytearray()
           elif ReplyRomRamPending == True :                # Si on est en cours de réception d'éléments de ROM/RAM
               ReplyRomRamIndex = ReplyRomRamIndex + 1      # Noter qu'un de plus est reçu
               if (item == CHAR_EOT) or (ReplyRomRamIndex == 16):             # fin de ROM/RAM ou Taille maximale reçue
                 DebugInput += "[EOT/EndOfRomRam]"
                 ReplyRomRamPending = False                 # On ne reçoit plus RAM/ROM
                 ReplyRomRamExpect = ReplyRomRamExpect - 1  # Une ROM/RAM attendue en moins
                 ReplyRomRam = ReplyRomRam + 1              # Au cas où, on se prépare pour attendre le prochain ROM/RAM
               if item != CHAR_EOT :                        # Ne pas stocker EOT
                 # Mémoriser le caractère reçu
                 DebugInput += item
                 if ReplyRomRam == 0 :                      # Attends ROM
                   GotRom += item.encode('utf-8')
                 elif ReplyRomRam == 1 :                    # Attends RAM1
                   GotRam1 += item.encode('utf-8')
                 elif ReplyRomRam == 2 :                    # Attends RAM2
                   GotRam2 += item.encode('utf-8')
               if ReplyRomRamPending == False :
                 # Juste pour débugage
                 if ReplyRomRam == 1 :                      # Attendait ROM
                   print("Updated ROM {}".format(GotRom))
                 elif ReplyRomRam == 2 :                    # Attendait RAM1
                   print("Updated RAM1 {}".format(GotRam1))
                 elif ReplyRomRam == 3 :                    # Attendait RAM2
                   print("Updated RAM2 {}".format(GotRam2))
           else :                                           # On n'est pas en cours de réception d'éléments de ROM/RAM
             AddItemToBufferNoRomRam(item)
        else :              # On ne s'attend pas à reçevoir ROM/RAM
          AddItemToBufferNoRomRam(item)
        
    if True:    # Constants
        CHAR_SOH  =chr(0x01)
        CHAR_EOT  =chr(0x04)
        CHAR_ENQ  =chr(0x05)
        CHAR_BS   =chr(0x08)
        CHAR_RC   =chr(0x0d)
        CHAR_CON  =chr(0x11)
        CHAR_REP  =chr(0x12)
        CHAR_SEP  =chr(0x13)
        CHAR_COFF =chr(0x14)
        CHAR_SS2  =chr(0x19)
        CHAR_ESC  =chr(0x1b)
        CHAR_US   =chr(0x1f)
        CHAR_PRO1 =chr(0x39)
        CHAR_PRO2 =chr(0x3a)
        CHAR_PRO3 =chr(0x3b)
        CHAR_CSI  =chr(0x5b)
        CHAR_ENVOI     ='A'
        CHAR_RETOUR    ='B'
        CHAR_REPETITION='C'
        CHAR_GUIDE     ='D'
        CHAR_ANNULATION='E'
        CHAR_SOMMAIRE  ='F'
        CHAR_CORRECTION='G'
        CHAR_SUITE     ='H'
        CHAR_CONNECTION='I'
        CHAR_CONNECTION_MODEM='Y'
        CHAR_ACCENT_LIST = ["@","A","B","C","D","E","F","G","H","I","J","K","L","M","N"]  # Liste des accents possibles (SS2 sur 3 caractères)
        #
        FIELD_POSV = 0
        FIELD_POSH = 1
        FIELD_ATTRIBS = 2
        FIELD_NAME = 3
        FIELD_SIZE = 4
        FIELD_FILL = 5
        
    if True:    # Init vars
        GotSep=False
        GotSS2=False
        GotEsc=False
        GotCsi=False
        GotProSeq = 0
        ProtocolSeq = ""
        GotCsiSeq=""
        GotLib=False
        DebugInput=""
        BufferInput=""
        BufferEcho =""
        DoSendPage=True
        #
        # Variables concernant la réception des réponses ROM/RAM
        #
        GotRom      = bytearray()  # Contenu ROM recu
        GotRam1     = bytearray()  # Contenu RAM1 recu
        GotRam2     = bytearray()  # Contenu RAM2 recu
        ReplyRomRamExpect  = 0     # Nb ROM/RAM attendu (0 = aucun)
        ReplyRomRamIndex   = 0     # Nb caractères recus dans ROM/RAM en cours
        ReplyRomRam        = 0     # Item ROM/RAM en attente (0=ROM, 1=RAM1, 2=RAM2)
        ReplyRomRamPending = False # ROM/RAM en cours de réception (SOH reçu)
        #
        # Variables concernant l'affichage des listes
        #
        NumPage    = bytearray()   # Numéro de page / Nb de pages pour une liste
        NumPages   = bytearray()   # Numéro de page / Nb de pages pour une liste
        #
        PrevField = -1 # Probablement inutile et à initialiser ailleurs
        #        
        DeclareField("Text01")
    #
    # Définition de la racine de l'arborescence - Prépare l'objet correspondant
    #
    MyArbo = Arbo("arbo")
    #
    # Arrivée sur la première page de l'arborescence
    #
    MyArbo.SetArbo("arbo_start")
    #
    # Demande le détail du contenu ROM/RAM et prépare leur réception
    #
    MyArbo.InsertBytes += (CHAR_ESC + CHAR_PRO1 + "{"+ CHAR_ENQ + CHAR_ESC + CHAR_PRO1 + "z").encode('utf-8') # ENQROM + ENQ RAM1 + ENQ RAM2
    ReplyRomRamExpect = 3 # Attends 3 items ROM/RAM
    ReplyRomRam = 0       # Attends ROM
    ReplyRomRamIndex = 0  # Aucun caractère reçu

    await websocket.send(f"Connected to {path} !")
    print ("SERVER START {}".format(path))
    while GotLib==False:
        if DoSendPage==True:
            #
            # Rafraichissement et mise en forme des variables à afficher, tel que défini dans l'arborescence 
            #
            MyArbo.InsertPostBytes=bytearray()
            CalcDisplayList()
                        
            for MyVar in MyArbo.VarList :
              MyTempStr=CHAR_US + chr(64+MyVar[0])+chr(64+MyVar[1])    # Positionnement au début
              for Attrib in MyVar[2]:                                # Ajout de chaque attribut défini
                MyTempStr += CHAR_ESC
                MyTempStr += Attrib
              MyTempVal=(vars().get(MyVar[3],"Udef:"+MyVar[3]))      # Valeur locale
              if type (MyTempVal) is int:
                MyTempVal = str(MyTempVal)
              if type (MyTempVal) is str:
                MyTempVal = MyTempVal.encode('utf-8')
              # Optimisations possibles si len(MyTempVal = 0)
              MyArbo.InsertPostBytes.extend (MyTempStr.encode('utf-8'))
              if MyVar[4]>0:
                MyArbo.InsertPostBytes.extend (MyVar[5].encode('utf-8'))
                if MyVar[4]>3:
                  MyArbo.InsertPostBytes.extend (CHAR_REP.encode('utf-8'))
                  MyArbo.InsertPostBytes.extend (chr(64+MyVar[4]-1).encode('utf-8'))
                else:
                  if MyVar[4]==3:
                    MyArbo.InsertPostBytes.extend (MyVar[5].encode('utf-8'))
                  MyArbo.InsertPostBytes.extend (MyVar[5].encode('utf-8'))
                MyArbo.InsertPostBytes.extend (MyTempStr.encode('utf-8'))                
              MyArbo.InsertPostBytes.extend (MyTempVal)

            #
            #
            # Rafraichissement et mise en forme des champs à afficher, le champ en cours de saisie en dernier, tel que défini dans l'arborescence 
            #
            MyArbo.InsertPostField=bytearray()
            # Champs qui ne sont pas en cours de saisie
            CountField = 0
            for MyVar in MyArbo.FieldList :
              if CountField != MyArbo.CurField :
                MyArbo.InsertPostField.extend (PresentFieldValue(MyVar))
              CountField = CountField + 1
            # Champ en cours de saisieh
            if len(MyArbo.FieldList) >0 :    # Si au moins 1 champ 
              MyArbo.InsertPostField.extend (PresentFieldValue(MyArbo.FieldList[MyArbo.CurField]))
              MyArbo.InsertPostField.extend (CHAR_CON.encode('utf-8')) # Curseur ON 
    
            try:
                page=GetPage(MyArbo.PageDir + MyArbo.PrefixFile + str(MyArbo.CurFile) + MyArbo.PostfixFile)
                print(f"SERVER SENT FILE '{MyArbo.PrefixFile+str(MyArbo.CurFile)+MyArbo.PostfixFile}'")
            except:
                page=(chr(12)+str(sys.exc_info()[0])+chr(10)+chr(13)+str(sys.exc_info()[1])).encode('utf-8')  #+chr(10)+chr(13)+str(sys.exc_info()[2])
                print ("ERR:Main.GetPage() "+str(sys.exc_info()[0])+" "+str(sys.exc_info()[1])+" "+str(sys.exc_info()[2]))
                MyArbo.CurFile=MyArbo.FirstFile
                pass
            # await websocket.send(MyArbo.InsertBytes) # + page)
            await websocket.send(MyArbo.InsertBytes + page + MyArbo.InsertPostBytes + MyArbo.InsertPostField)
            MyArbo.InsertBytes = bytearray() # Clear possible previous page content prefix
            DoSendPage=False
            RefreshCurField=False



        if RefreshCurField==True :
          RefreshCurField=False
          if len(MyArbo.FieldList) >0 :    # Si au moins 1 champ 
            #
            # Rafraichissement et mise en forme des champs à afficher, le champ précédent puis le champs en cours de saisie, tel que défini dans l'arborescence 
            #                                                              
            MyArbo.InsertPostField=bytearray()
            # Champs précédement en cours de saisie
            if DoRefreshPrevField == True :
              if PrevField >= 0:
                MyArbo.InsertPostField.extend (PresentFieldValue(MyArbo.FieldList[PrevField]))
              PrevField = -1
            # Champ en cours de saisie
            MyArbo.InsertPostField.extend (PresentFieldValue(MyArbo.FieldList[MyArbo.CurField]))
            MyArbo.InsertPostField.extend (CHAR_CON.encode('utf-8')) # Curseur ON           
            await websocket.send(MyArbo.InsertPostField)
          
                                            

        if len(BufferEcho) :
          await websocket.send(BufferEcho.encode('utf-8'))
          BufferEcho=""          

        try:
          RawReceived = await websocket.recv()
        except (websockets.exceptions.ConnectionClosedOK , websockets.exceptions.ConnectionClosedError) :
          print ("ERR:Main.recv() "+str(sys.exc_info()[0])+" "+str(sys.exc_info()[1])+" "+str(sys.exc_info()[2]))
          GotLib=True
          pass
        # https://stackoverflow.com/questions/45229304/await-only-for-some-time-in-python
        # https://stackoverflow.com/questions/37663560/websocket-recv-never-returns-inside-another-event-loop
        # https://stackoverflow.com/questions/54421029/python-websockets-how-to-setup-connect-timeout
        for item in RawReceived:        # Analyse le paquet reçu
            if item == CHAR_ESC:        # Annonce une sequence ESC
                GotEsc=True
            else:
                if GotEsc==True:        # Traitement d'une sequence ESC reçue
                    if item == CHAR_PRO1:   # Annonce une sequence PRO1
                        GotEsc=False
                    if item == CHAR_PRO2:   # Annonce une sequence PRO2
                        GotEsc=False
                    if item == CHAR_PRO3:   # Annonce une sequence PRO3
                        GotEsc=False
                    if GotEsc == False:     # Annonce une sequence protocole
                        GotProSeq = (ord(item) - ord(CHAR_PRO1))+1
                        ProtocolSeq = ""
                        DebugInput += "<PRO{}> ".format(GotProSeq)
                    else:
                        GotEsc=False
                        if item == CHAR_CSI:
                            GotCsi = True
                            GotCsiSeq = ""
                        else:
                            AddItemToBuffer(CHAR_ESC)
                            AddItemToBuffer(item)       # Ici, il faudrait pouvoir traiter directement un code de contrôle [BUG!]
                else:                               # On n'est pas dans le traitement d'une sequence ESC reçue
                    if GotProSeq > 0:               # On est dans le traitement d'une sequence protocole
                        ProtocolSeq += item         # Ici aussi, il faudrait pouvoir traiter directement un code de contrôle [BUG!]
                        GotProSeq -=1
                        if GotProSeq == 0:
                            BufferInput+=CHAR_ESC
                            BufferInput+=chr(ord(CHAR_PRO1)+len(GotProSeq)-1)
                            for item in ProtocolSeq:
                                BufferInput+=item
                                DebugInput += "<0x{:02x}> ".format(ord(item))
                    else:                       # On n'est pas dans le traitement d'une sequence protocole reçue
                        if GotCsi == True:
                            GotCsiSeq += item         # Ici aussi, il faudrait pouvoir traiter directement un code de contrôle [BUG!]
                            if ord(item) >= 0x40:
                                GotCsi = False
                                BufferInput+=CHAR_ESC
                                BufferInput+=CHAR_CSI
                                DebugInput += "[CSI]"
                                for item in GotCsiSeq:
                                    AddItemToBuffer(item)
                        else:
                            if item == CHAR_SEP:    # Annonce une touche de fonction
                                GotSep=True
                            else:
                                if GotSep==True:    # Traitement d'une touche de fonction reçue
                                    if item == CHAR_ENVOI:
                                        GotSep=False
                                        DebugInput += "[ENVOI]"
                                        if len(MyArbo.FieldList)>0 :
                                          UpdateCurField()
                                          LoadBufferInputWithCurField()
                                          if len (MyArbo.CurrentList) >0:
                                            print (MyArbo.CurrentList)
                                            #MyArbo.FieldList[MyArbo.CurField][FIELD_NAME],MySession)
                                            #print(int(MyArbo.FieldList[MyArbo.CurField][FIELD_NAME],base=10))
                                            try:
                                              MyItem=int(BufferInput)
                                            except ValueError:
                                              MyItem=0
                                              pass 
                                            if (MyItem>0) :
                                              if (MyItem<=len(MyArbo.CurrentList)):
                                                print("Item Selected '" + MyArbo.CurrentList[MyItem-1][0] + "' in " + MyArbo.DisplayList[0])
                                              else:
                                                print("$InvalidItemSelected$")
                                            
#
# https://stackoverflow.com/questions/1450275/any-way-to-modify-locals-dictionary
#
#    refs    = locals()
#    def set_pets():
#        global refs
#        animals = ('dog', 'cat', 'fish', 'fox', 'monkey')
#        for i in range(len(animals)):
#            refs['pet_0%s' % i] = animals[i]   
#    set_pets()
#    refs['pet_05']='bird'
#    print(pet_00, pet_02, pet_04, pet_01, pet_03, pet_05 )
#    >> dog fish monkey cat fox bird
#And if you want to test your dict before putting it in locals():
#
#def set_pets():
#    global refs
#    sandbox = {}
#    animals = ('dog', 'cat', 'fish', 'fox', 'monkey')
#    for i in range(len(animals)):
#        sandbox['pet_0%s' % i] = animals[i]
#    # Test sandboxed dict here
#    refs.update( sandbox )
                                    if item == CHAR_SUITE:
                                        GotSep=False
                                        DebugInput += "[SUITE]"
                                        #
                                        # Traitement des séquences de pages
                                        #
                                        if MyArbo.CurFile==MyArbo.LastFile:
                                            if MyArbo.CurFile==MyArbo.FirstFile:
                                                DebugInput += "$OnlyOnePage$"
                                            else:
                                                MyArbo.CurFile=MyArbo.FirstFile
                                                DoSendPage=True
                                        else:
                                            DoSendPage=True
                                            MyArbo.CurFile+=1
                                        #
                                        # Traitement des listes de champs
                                        #
                                        if (MyArbo.CurField+1)>len(MyArbo.FieldList):
                                          DebugInput += "$NoField$"
                                        elif (MyArbo.CurField+1)==len(MyArbo.FieldList):
                                          if len(MyArbo.FieldList)==1:
                                            DebugInput += "$OnlyOneField$"
                                          else:
                                            UpdateCurField()
                                            PrevField=MyArbo.CurField
                                            RefreshCurField=True
                                            MyArbo.CurField=0
                                            LoadBufferInputWithCurField()
                                        else:
                                          UpdateCurField()
                                          PrevField=MyArbo.CurField
                                          RefreshCurField=True
                                          MyArbo.CurField+=1
                                          LoadBufferInputWithCurField()
                                          
                                    if item == CHAR_RETOUR:
                                        GotSep=False
                                        DebugInput += "[RETOUR]"
                                        #
                                        # Traitement des séquences de pages
                                        #
                                        if MyArbo.CurFile==MyArbo.FirstFile:
                                            if MyArbo.CurFile==MyArbo.LastFile:
                                                DebugInput += "$OnlyOnePage$"
                                            else:
                                                MyArbo.CurFile=MyArbo.LastFile
                                                DoSendPage=True
                                        else:
                                            DoSendPage=True
                                            MyArbo.CurFile-=1
                                        #
                                        # Traitement des listes de champs
                                        #
                                        if (MyArbo.CurField+1)>len(MyArbo.FieldList):
                                          DebugInput += "$NoField$"
                                        elif len(MyArbo.FieldList)==1:
                                            DebugInput += "$OnlyOneField$"
                                        else:
                                          UpdateCurField()
                                          RefreshCurField=True
                                          PrevField=MyArbo.CurField
                                          if MyArbo.CurField >0:
                                              MyArbo.CurField-=1
                                              LoadBufferInputWithCurField()
                                          else:
                                              MyArbo.CurField=len(MyArbo.FieldList)-1
                                              LoadBufferInputWithCurField()
                                        
                                    if item == CHAR_REPETITION:
                                        GotSep=False
                                        DebugInput += "[REPETITION]"
                                        DoSendPage=True
                                    if item == CHAR_CORRECTION:
                                        GotSep=False
                                        DebugInput += "[CORRECTION]"
                                        #
                                        # Traitement du champ
                                        #
                                        if len(MyArbo.FieldList):
                                          Cont=True
                                          Removed = False
                                          while (Cont == True) :
                                            #print("<0x{:02x}> ".format(ord(BufferInput[-2:-1])))
                                            if (Cont == True) and (len(BufferInput) > 1) and (ord(BufferInput[-2:-1]) == ord(CHAR_SS2.encode('utf-8'))) :
                                                if chr(ord(BufferInput[-1:])) in CHAR_ACCENT_LIST :
                                                  print("Accent sans caractère retiré silencieusement du buffer - Précédent chr sera aussi à retirer")
                                                  pass        # Accent sans caractère retiré silencieusement du buffer - Précédent chr sera aussi à retirer
                                                else :
                                                  Cont=False  # Caractère spécial retiré du buffer 
                                                  print ("Caractère spécial retiré du buffer")
                                                  Removed = True
                                                BufferInput = BufferInput[:-2]
                                            else :
                                              if (Cont == True) and (len(BufferInput) > 2) and (ord(BufferInput[-3:-2]) == ord(CHAR_SS2.encode('utf-8'))) :
                                                  if chr(ord(BufferInput[-2:-1])) in CHAR_ACCENT_LIST :
                                                    Cont=False  # Caractère accentué retiré du buffer
                                                    print("Caractère accentué retiré du buffer")
                                                    Removed = True
                                                    BufferInput = BufferInput[:-3]
                                              else :
                                                if (Cont == True) and (len(BufferInput)>0) :
                                                  Cont=False  # Caractère normal retiré du buffer
                                                  print("Caractère normal retiré du buffer")
                                                  Removed = True
                                                  BufferInput = BufferInput[:-1]
                                                else :
                                                  print("Aucun caractere retiré")
                                                  Cont = False
                                          if Removed == True :
                                              await websocket.send((CHAR_BS + MyArbo.FieldList[MyArbo.CurField][FIELD_FILL] + CHAR_BS).encode('utf-8'))
                                          else :
                                            DebugInput += "$EmptyBufferInput$"
                                            
                                    if item == CHAR_ANNULATION:
                                        GotSep=False
                                        DebugInput += "[ANNULATION]"
                                        #
                                        # Traitement du champ
                                        #
                                        if len(MyArbo.FieldList):
                                          UpdateField(MyArbo.FieldList[MyArbo.CurField][FIELD_NAME],MySession,"")
                                          ClearBufferInput()
                                          RefreshCurField=True
                                          
                                    if item == CHAR_GUIDE:
                                        GotSep=False
                                        DebugInput += "[GUIDE]"
                                        if len(MyArbo.GuideLink)>0:
                                            MyArbo.StackList.append(MyArbo.ArboCur)
                                            MyArbo.SetArbo(MyArbo.GuideLink)
                                            DoSendPage=True
                                        else:
                                            DebugInput += "$NoGuideDefined$"
                                        #
                                        # Traitement du champ
                                        #
                                        if len(MyArbo.FieldList) and (DoSendPage==True):
                                          ClearBufferInput()

                                    if item == CHAR_SOMMAIRE:
                                        GotSep=False
                                        DebugInput += "[SOMMAIRE]"  
                                        if not MyArbo.StackList :
                                            DebugInput += "$TopLevelReached$"
                                        else :                                       
                                          MyArbo.SetArbo(MyArbo.StackList.pop())
                                          DoSendPage=True
                                        #
                                        # Traitement du champ
                                        #
                                        if len(MyArbo.FieldList) and (DoSendPage==True):
                                          ClearBufferInput()
                                        
                                    if item == CHAR_CONNECTION:
                                        GotLib=True
                                        GotSep=False
                                        DebugInput += "[CONNECTION]"
                                        break
                                    if item == CHAR_CONNECTION_MODEM:
                                        GotLib=True
                                        GotSep=False
                                        DebugInput += "[CONNECTION_MODEM]"
                                        break
                                    if GotSep==True:
                                        GotSep=False                        
                                        if item > ' ':
                                            DebugInput += "<SEP>"+item
                                        else:
                                            DebugInput += "<SEP><0x{:02x}> ".format(ord(item))
                                else:
                                    AddItemToBuffer(item)
        if len (DebugInput) > 0:
            print(f"SERVER GOT '{DebugInput}'")
            DebugInput=""
    print(f"SERVER GOT '{DebugInput}' EXITING")
    DebugInput=""
  finally:
    NumSession=NumSession - 1
    print("FINALLY")
    #
    # Do whatever is necessary to save/close after the session completes
    FreeAllFields()
    #
    SessionId=-1
    SessionCount=0
    try:
      lock.acquire()
      for Session in ListSession :
        if Session[0] == MySession :
          SessionId=SessionCount
        SessionCount += 1
      if SessionId > -1 :
        ListSession.pop(SessionId)
        print ("Deleted session " + str(MySession))
    finally :
        lock.release()
                  
    for Session in ListSession :
      print(Session)
        
try:
  asyncio.get_event_loop().set_debug(False)
  #logging.basicConfig(level=logging.DEBUG)
  #https://pymotw.com/3/asyncio/debugging.html 
  
  start_server = websockets.serve(hello, "localhost", 8765)
  asyncio.get_event_loop().run_until_complete(start_server)
  asyncio.get_event_loop().set_exception_handler(handle_exception)
  asyncio.get_event_loop().run_forever()
except:
  print ("ERR:Main() "+str(sys.exc_info()[0])+" "+str(sys.exc_info()[1])+" "+str(sys.exc_info()[2]))
  err=sys.exc_info()
  for item in err:
    print(item)
finally:
  print("Pending tasks at exit: %s" % asyncio.Task.all_tasks(asyncio.get_event_loop()))
  asyncio.get_event_loop().close()
