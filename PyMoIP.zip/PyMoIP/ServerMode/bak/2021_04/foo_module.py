#from test import print_something

def bar(global_refs,local_refs,comment):
  #__import__("test", globals(), locals(), ["print_something()"], 0)
  print ("Exec Bar (" + comment + ")")
  #print_something()
  #
  # Ceci est une variable locale
  #
  zizi="Variable locale"
  #
  # Variables globales
  #
  global_refs['pet_06']='truc_bar'    # Modification d'une variable globale
  #
  print("Zizi est : " + zizi)
  print("Pet_05 est : " + global_refs['pet_05'])
  #
  # Variables locales � hello (module parent)
  #
  print(local_refs['Blabla'])
  (local_refs['Blabla'])='BarWozHere'  # Modification d'une variable locale au module parent ==> Ne fonctionne pas !!!
  print(local_refs['Blabla'])
  #
  # Objet local � hello (module parent)
  #
  print("Item d'un objet du module parent : " + (local_refs['MyArbo']).ArboCur)
  (local_refs['MyArbo']).ArboCur="BarWazHereToo"    # Modification d'un objet local au module parent
