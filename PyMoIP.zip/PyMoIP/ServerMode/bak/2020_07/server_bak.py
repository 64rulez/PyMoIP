#!/usr/bin/env python

# WS server example
import sys

import asyncio
import websockets

def GetPage(fichier):
    # "Envoi du contenu d'un fichier"
    f = open(fichier, 'rb')
    contents=f.read()
    f.close()
    return (contents)

async class hello(websocket, path):
    #FirstFile=11
    #LastFile=13
    #PrefixFile="J"
    #PostfixFile=".vdt"

    FirstFile=101
    LastFile=125
    PrefixFile=""
    PostfixFile=""
    
    ArboRoot="arbo."
    ArboCur="arbo_start"
    
    def InitArbo (self):
        #from arbo.arbo_start import FirstFile, LastFile, PrefixFile, PostfixFile, PageDir, GuideLink
        _temp = __import__(self.ArboRoot+self.ArboCur, globals(), locals(), ['FirstFile', 'LastFile', 'PrefixFile', 'PostfiFile', 'PageDir', 'GuideLink'], 0)
        self.FirstFile = _temp.FirstFile
        self.LastFile = _temp.LastFile
        self.PrefixFile = _temp.PrefixFile
        self.PostfixFile = _temp.PostfixFile
        self.PageDir = _temp.PageDir
        self.GuideLink = _temp.GuideLink
        self.CurFile=self.FirstFile
    self.InitArbo()
    
    if True:    # Constants
        CHAR_RC   =chr(0x0d)
        CHAR_ESC  =chr(0x1b)
        CHAR_SEP  =chr(19)
        CHAR_PRO1 =chr(0x39)
        CHAR_PRO2 =chr(0x3a)
        CHAR_PRO3 =chr(0x3b)
        CHAR_ENVOI     ='A'
        CHAR_RETOUR    ='B'
        CHAR_REPETITION='C'
        CHAR_GUIDE     ='D'
        CHAR_ANNULATION='E'
        CHAR_SOMMAIRE  ='F'
        CHAR_CORRECTION='G'
        CHAR_SUITE     ='H'
        CHAR_CONNECTION='I'
        CHAR_CONNECTION_MODEM='Y'
        
    if True:    # Init vars
        GotSep=False
        GotEsc=False
        DebugInput=""
        BufferInput=""
        DoSendPage=True

    await websocket.send(f"Connected to {path} !")
    print ("SERVER SAYS {}".format(path))
    while True:
        if DoSendPage==True:
            try:
                page=GetPage(PageDir + PrefixFile + str(CurFile) + PostfixFile)
                print(f"SERVER SENT FILE '{PrefixFile+str(CurFile)+PostfixFile}'")
            except:
                page=chr(12)+str(sys.exc_info()[0])+chr(10)+chr(13)+str(sys.exc_info()[1])  #+chr(10)+chr(13)+str(sys.exc_info()[2])
                CurFile=FirstFile
                pass
            await websocket.send(page)
            DoSendPage=False
        RawReceived = await websocket.recv()
        for item in RawReceived:
            if item == CHAR_SEP:
                GotSep=True
            else:
                if GotSep==True:    # Traitement d'une touche de fonction reçue
                    if item == CHAR_RC:
                        GotSep=False
                        DebugInput += "[RC]"
                    if item == CHAR_ENVOI:
                        GotSep=False
                        DebugInput += "[ENVOI]"
                    if item == CHAR_SUITE:
                        GotSep=False
                        DebugInput += "[SUITE]"
                        if CurFile==LastFile:
                            if CurFile==FirstFile:
                                DebugInput += "$OnlyOnePage$"
                            else:
                                CurFile=FirstFile
                                DoSendPage=True
                        else:
                            DoSendPage=True
                            CurFile+=1
                    if item == CHAR_RETOUR:
                        GotSep=False
                        DebugInput += "[RETOUR]"
                        if CurFile==FirstFile:
                            if CurFile==LastFile:
                                DebugInput += "$OnlyOnePage$"
                            else:
                                CurFile=LastFile
                                DoSendPage=True
                        else:
                            DoSendPage=True
                            CurFile-=1
                    if item == CHAR_REPETITION:
                        GotSep=False
                        DebugInput += "[REPETITION]"
                        DoSendPage=True
                    if item == CHAR_CORRECTION:
                        GotSep=False
                        DebugInput += "[CORRECTION]"
                    if item == CHAR_ANNULATION:
                        GotSep=False
                        DebugInput += "[ANNULATION]"
                    if item == CHAR_GUIDE:
                        GotSep=False
                        DebugInput += "[GUIDE]"
                        if len(GuideLink)>0:
                            ArboCur=GuideLink
                            self.InitArbo()

                    if item == CHAR_SOMMAIRE:
                        GotSep=False
                        DebugInput += "[SOMMAIRE]"
                    if item == CHAR_CONNECTION:
                        GotSep=False
                        DebugInput += "[CONNECTION]"
                        break
                    if item == CHAR_CONNECTION_MODEM:
                        GotSep=False
                        DebugInput += "[CONNECTION_MODEM]"
                        break
                    if GotSep==True:
                        GotSep=False                        
                        if item > ' ':
                            DebugInput += "<SEP>"+item
                        else:
                            DebugInput += "<SEP><0x{:02x}> ".format(ord(item))
                else:
                    BufferInput+=item
                    if item > ' ':
                        DebugInput += item
                    else:
                        DebugInput += "<0x{:02x}> ".format(ord(item))
        if len (DebugInput) > 0:
            print(f"SERVER GOT '{DebugInput}'")
            DebugInput=""
    print(f"SERVER GOT '{DebugInput}' EXITING")
    DebugInput=""

    

start_server = websockets.serve(hello, "localhost", 8765)


asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
