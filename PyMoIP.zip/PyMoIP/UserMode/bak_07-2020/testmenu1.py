#!/usr/bin/env python
# -*- coding: utf-8 -*-

from serial import Serial      # Liaison physique avec le Minitel
import time
from minitel.Minitel import Minitel,Empty
from minitel.ui.Menu import Menu
from minitel.ui.ChampTexte import ChampTexte
from minitel.ui.Label import Label
from minitel.ui.MyClass import MyClass



MyComDevice = '/dev/ttyUSB0'
print ( "Hello {}".format(MyComDevice) )

minitel = Minitel(MyComDevice)

vitesse_initiale = minitel.deviner_vitesse()
vitesse_souhaitee = 4800

print ( "Vitesse initiale : {} Bds".format(vitesse_initiale))
if vitesse_initiale == -1:
    print ( "Vitesse non identifiee ou pas de minitel")
    exit()
minitel.identifier()
print ( minitel.capacite['nom'] )
if vitesse_initiale != vitesse_souhaitee:
    retry_vitesse = 3
    while retry_vitesse > 0:
      if not ( minitel.definir_vitesse(vitesse_souhaitee)):
        retry_vitesse -= 1
        if retry_vitesse == 0:
          print ( "Echec de définition de la vitesse souhaitee" )
          exit()
        else:
          print ("Retry vitesse souhaitee" )
          while not minitel.sortie.empty():
            time.sleep(1)
          time.sleep(1)

      else:
        retry_vitesse = 0
    #minitel._minitel.close()
    print ( "Vitesse souhaitee : {} Bds".format(vitesse_souhaitee))
    minitel._minitel= Serial(
            MyComDevice,
            baudrate = vitesse_souhaitee, # vitesse à 1200 bps, le standard Minitel
            bytesize = 7,    # taille de caractère à 7 bits
            parity   = 'E',  # parité paire
            stopbits = 1,    # 1 bit d’arrêt
            timeout  = 1,    # 1 bit de timeout
            xonxoff  = 0,    # pas de contrôle logiciel
            rtscts   = 0     # pas de contrôle matériel
    )
 
minitel.definir_mode('VIDEOTEX')
minitel.configurer_clavier(etendu = True, curseur = False, minuscule = True)
minitel.echo(False)
minitel.efface()
minitel.curseur(False)

print ( minitel.capacite )

conteneur = MyClass(minitel, 1, 1, 32, 17, 'blanc', 'bleu',"PageToto.vdt")

options = [
  'Nouveau',
  'Ouvrir',
  '-',
  'Enregistrer',
  'Enreg. sous...',
  'Rétablir',
  '-',
  'Aperçu',
  'Imprimer...',
  '-',
  'Fermer',
  'Quitter'
]

labelMenu = Label(minitel, 2, 2, "Menu", 'jaune')
menu = Menu(minitel, options, 9, 1)

labelNom = Label(minitel, 2, 15, "Nom", 'jaune')
champNom = ChampTexte(minitel, 10, 15, 20, 60)

labelPrenom = Label(minitel, 2, 16, "Prénom", 'jaune')
champPrenom = ChampTexte(minitel, 10, 16, 20, 60)

conteneur.ajoute(labelMenu)
conteneur.ajoute(menu)
conteneur.ajoute(labelNom)
conteneur.ajoute(champNom)
conteneur.ajoute(labelPrenom)
conteneur.ajoute(champPrenom)
conteneur.affiche()
conteneur.executer()
print ( "conteneur" )
print ( conteneur )


MyItem=0

#menu = Menu(minitel, options, 15, 3, MyItem, 'bleu')
#menu.affiche()
#menu.executer()




while True:
    try:
        r = minitel.recevoir_sequence(attente=30)
        # r = minitel.entree.get(True , 30)
        # print ( r )
        MyItem += 1
        if MyItem >= len (options):
            MyItem = 0
        while options[MyItem] == '-':
            MyItem += 1
            if MyItem >= len (options):
                MyItem = 0
        print ( "Longueur" )
        print (r.longueur )
        print ( "Valeurs" )
        for element in r.valeurs:
            print ( element )
        menu.change_selection (MyItem)
    except Empty :
        print ( "Rien.." )
        pass


minitel.close()
print ( "Goodbye" )

